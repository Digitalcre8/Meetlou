import { createContext, useContext, useEffect, useMemo, useReducer, type ReactNode } from 'react';
import {
  CASE_ID,
  caseRecord,
  initialReadReceipts,
  initialTasks,
  initialTimelineEvents,
  participants,
} from '../data/mockData';
import type { Case, Participant, ReadReceipt, Task, TimelineEvent } from '../types';

export type TabId = 'live' | 'timeline' | 'documents' | 'people' | 'tasks';

interface CaseState {
  caseRecord: Case;
  participants: Participant[];
  timelineEvents: TimelineEvent[];
  readReceipts: ReadReceipt[];
  tasks: Task[];
  activeTab: TabId;
  highlightEventId: string | null;
}

type Action =
  | { type: 'TICK' }
  | { type: 'SIMULATE_CALL' }
  | { type: 'SET_ACTIVE_TAB'; tab: TabId }
  | { type: 'GO_TO_EVENT'; eventId: string };

const initialState: CaseState = {
  caseRecord,
  participants,
  timelineEvents: initialTimelineEvents,
  readReceipts: initialReadReceipts,
  tasks: initialTasks,
  activeTab: 'live',
  highlightEventId: null,
};

function reducer(state: CaseState, action: Action): CaseState {
  switch (action.type) {
    case 'TICK': {
      const timelineEvents = state.timelineEvents.map((evt) => {
        if (evt.status === 'live' && evt.kind === 'call') {
          return { ...evt, durationSeconds: (evt.durationSeconds ?? 0) + 1 };
        }
        if (evt.status === 'processing' && evt.kind === 'document_upload') {
          const next = Math.min(100, (evt.progressPercent ?? 0) + 1 + Math.floor(Math.random() * 3));
          return {
            ...evt,
            progressPercent: next,
            status: next >= 100 ? ('complete' as const) : evt.status,
            title: next >= 100 ? evt.title.replace('Uploading', 'Uploaded') : evt.title,
          };
        }
        return evt;
      });
      return { ...state, timelineEvents };
    }
    case 'SIMULATE_CALL': {
      const timelineEvents = state.timelineEvents.map((evt) =>
        evt.id === 'evt-live-call'
          ? { ...evt, status: 'live' as const, durationSeconds: 0, createdAt: new Date().toISOString() }
          : evt,
      );
      return { ...state, timelineEvents };
    }
    case 'SET_ACTIVE_TAB':
      return { ...state, activeTab: action.tab, highlightEventId: null };
    case 'GO_TO_EVENT':
      return { ...state, activeTab: 'timeline', highlightEventId: action.eventId };
    default:
      return state;
  }
}

interface CaseContextValue extends CaseState {
  simulateIncomingCall: () => void;
  setActiveTab: (tab: TabId) => void;
  goToEvent: (eventId: string) => void;
}

const CaseContext = createContext<CaseContextValue | null>(null);

export function CaseProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(reducer, initialState);

  useEffect(() => {
    const id = window.setInterval(() => dispatch({ type: 'TICK' }), 1000);
    return () => window.clearInterval(id);
  }, []);

  const value = useMemo<CaseContextValue>(
    () => ({
      ...state,
      simulateIncomingCall: () => dispatch({ type: 'SIMULATE_CALL' }),
      setActiveTab: (tab) => dispatch({ type: 'SET_ACTIVE_TAB', tab }),
      goToEvent: (eventId) => dispatch({ type: 'GO_TO_EVENT', eventId }),
    }),
    [state],
  );

  return <CaseContext.Provider value={value}>{children}</CaseContext.Provider>;
}

export function useCase() {
  const ctx = useContext(CaseContext);
  if (!ctx) throw new Error('useCase must be used within CaseProvider');
  return ctx;
}

export function useReadReceiptsFor(eventId: string): ReadReceipt[] {
  const { readReceipts } = useCase();
  return readReceipts.filter((r) => r.timelineEventId === eventId);
}

export { CASE_ID };
