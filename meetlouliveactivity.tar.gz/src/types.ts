export type ParticipantRole =
  | 'you'
  | 'buyer'
  | 'seller'
  | 'estate_agent'
  | 'solicitor'
  | 'mortgage_broker'
  | 'surveyor';

export interface Participant {
  id: string;
  name: string;
  initials: string;
  role: ParticipantRole;
}

export type TimelineEventKind =
  | 'call'
  | 'email_sync'
  | 'document_upload'
  | 'note'
  | 'confirmation';

export type TimelineEventStatus = 'live' | 'processing' | 'complete';

export interface TimelineEvent {
  id: string;
  caseId: string;
  kind: TimelineEventKind;
  title: string;
  createdAt: string;
  status: TimelineEventStatus;

  // capture
  durationSeconds?: number;
  progressPercent?: number;
  emailCount?: number;

  // understand (AI extraction)
  aiSummary?: string;
  decision?: string;
  action?: string;
  deadline?: string;
  verified?: boolean;

  // coordinate
  actorParticipantId?: string;
  actorLabel?: string;
}

export interface ReadReceipt {
  timelineEventId: string;
  participantId: string;
  readAt: string | null;
}

export interface Task {
  id: string;
  caseId: string;
  title: string;
  dueDate?: string;
  done: boolean;
}

export interface Case {
  id: string;
  title: string;
  address: string;
  participantIds: string[];
}
