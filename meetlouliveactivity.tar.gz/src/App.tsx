import { CaseProvider } from './state/CaseProvider';
import { CaseDetail } from './pages/CaseDetail';

export default function App() {
  return (
    <CaseProvider>
      <div className="min-h-screen bg-background">
        <CaseDetail />
      </div>
    </CaseProvider>
  );
}
