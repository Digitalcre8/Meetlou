import { useCase } from '../../state/CaseProvider';
import { StatusPill } from '../StatusPill';
import { Waveform } from '../Waveform';
import { ProgressBar } from '../ProgressBar';
import { formatDuration } from './formatDuration';

export function CaptureColumn() {
  const { timelineEvents, goToEvent } = useCase();

  const call = timelineEvents.find((e) => e.id === 'evt-live-call')!;
  const emailSync = timelineEvents.find((e) => e.id === 'evt-email-sync')!;
  const upload = timelineEvents.find((e) => e.id === 'evt-upload-survey')!;

  const isRecording = call.status === 'live';

  return (
    <div className="flex flex-col">
      <span className="font-mono text-[11px] uppercase tracking-label text-terracotta">Capture</span>

      <div className="mt-2 rounded-card border border-hairline bg-white p-4">
        <div className="flex items-center justify-between">
          <span className="font-mono text-[11px] uppercase tracking-label text-stone">Capturing</span>
          {isRecording && (
            <StatusPill tone="recording" label={`REC ${formatDuration(call.durationSeconds ?? 0)}`} />
          )}
        </div>

        <button
          onClick={() => goToEvent(call.id)}
          className="mt-3 flex w-full items-center justify-between text-left"
        >
          <span className="font-heading text-base font-semibold text-ink">{call.title}</span>
          {isRecording && <span className="text-xs text-terracotta">Live</span>}
        </button>

        <div className="mt-3">
          <Waveform active={isRecording} />
        </div>

        <p className="mt-2 text-xs text-stone">Auto-transcribing · summary ready when you hang up</p>
      </div>

      <div className="mt-3 space-y-2">
        <div className="rounded-lg border border-hairline bg-white px-3 py-2.5">
          <div className="flex items-center justify-between text-sm">
            <span className="text-ink">{emailSync.title}</span>
            <span className="font-mono text-[11px] uppercase tracking-label text-emerald-700">✓ Done</span>
          </div>
        </div>

        <button
          onClick={() => goToEvent(upload.id)}
          className="block w-full rounded-lg border border-hairline bg-white px-3 py-2.5 text-left"
        >
          <div className="flex items-center justify-between text-sm">
            <span className="text-ink">{upload.title}</span>
            <span className="font-mono text-[11px] text-stone">{upload.progressPercent ?? 0}%</span>
          </div>
          <div className="mt-2">
            <ProgressBar percent={upload.progressPercent ?? 0} />
          </div>
        </button>
      </div>

      <div className="mt-4">
        <p className="font-heading text-base font-semibold text-ink">
          Record calls, upload documents and sync email.
        </p>
        <p className="mt-1 text-sm text-stone">
          A dedicated line and address per move — nothing else is ever seen.
        </p>
      </div>
    </div>
  );
}
