import { useCase, useReadReceiptsFor } from '../../state/CaseProvider';
import { AvatarStack } from '../AvatarStack';
import { timeAgo } from './timeAgo';

function ActivityCard({
  title,
  status,
  statusTone,
  onClick,
}: {
  title: string;
  status: string;
  statusTone: 'terracotta' | 'stone';
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className="block w-full rounded-lg border border-hairline bg-white px-3 py-2.5 text-left"
    >
      <p className="text-sm text-ink">{title}</p>
      <p className={`mt-1 text-xs ${statusTone === 'terracotta' ? 'text-terracotta' : 'text-stone'}`}>
        {status}
      </p>
    </button>
  );
}

export function CoordinateColumn() {
  const { caseRecord, participants, timelineEvents, goToEvent } = useCase();

  const people = participants.filter((p) => caseRecord.participantIds.includes(p.id));

  const shareEvent = timelineEvents.find((e) => e.id === 'evt-share-mortgage-offer')!;
  const noteEvent = timelineEvents.find((e) => e.id === 'evt-note-solicitor')!;
  const confirmEvent = timelineEvents.find((e) => e.id === 'evt-confirm-viewing')!;

  const shareReceipts = useReadReceiptsFor(shareEvent.id);
  const confirmReceipts = useReadReceiptsFor(confirmEvent.id);

  const shareReadByEveryone = shareReceipts.length > 0 && shareReceipts.every((r) => r.readAt);
  const confirmReadCount = confirmReceipts.filter((r) => r.readAt).length;

  return (
    <div className="flex flex-col">
      <span className="font-mono text-[11px] uppercase tracking-label text-terracotta">Coordinate</span>

      <div className="mt-2 rounded-card border border-hairline bg-white p-4">
        <div className="flex items-center justify-between">
          <span className="font-mono text-[11px] uppercase tracking-label text-stone">
            Everyone in the loop
          </span>
          <span className="font-mono text-[11px] uppercase tracking-label text-stone">
            {people.length} people
          </span>
        </div>

        <div className="mt-3">
          <AvatarStack people={people} />
        </div>

        <div className="mt-3 space-y-2">
          <ActivityCard
            title={shareEvent.title}
            status={shareReadByEveryone ? '✓✓ Read by everyone' : '✓✓ Sent'}
            statusTone="terracotta"
            onClick={() => goToEvent(shareEvent.id)}
          />
          <ActivityCard
            title={noteEvent.title}
            status={timeAgo(noteEvent.createdAt)}
            statusTone="stone"
            onClick={() => goToEvent(noteEvent.id)}
          />
          <ActivityCard
            title={confirmEvent.title}
            status={`Read by ${confirmReadCount}`}
            statusTone="stone"
            onClick={() => goToEvent(confirmEvent.id)}
          />
        </div>
      </div>

      <div className="mt-4">
        <p className="font-heading text-base font-semibold text-ink">
          One timeline, shared securely. Everyone sees what they need.
        </p>
      </div>
    </div>
  );
}
