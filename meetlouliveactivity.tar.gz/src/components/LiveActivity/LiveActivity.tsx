import { useCase } from '../../state/CaseProvider';
import { CaptureColumn } from './CaptureColumn';
import { UnderstandColumn } from './UnderstandColumn';
import { CoordinateColumn } from './CoordinateColumn';

export function LiveActivity() {
  const { simulateIncomingCall } = useCase();

  return (
    <div>
      <div className="mb-4 flex items-center justify-between">
        <h2 className="font-heading text-lg font-semibold text-ink">Live activity</h2>
        <button
          onClick={simulateIncomingCall}
          className="rounded-full border border-terracotta px-3 py-1.5 font-mono text-[11px] uppercase tracking-label text-terracotta hover:bg-terracotta hover:text-white transition-colors"
        >
          Simulate incoming call
        </button>
      </div>

      <div className="flex gap-4 overflow-x-auto pb-2 snap-x snap-mandatory md:grid md:grid-cols-3 md:gap-6 md:overflow-visible">
        <div className="min-w-[85%] shrink-0 snap-center md:min-w-0">
          <CaptureColumn />
        </div>
        <div className="min-w-[85%] shrink-0 snap-center md:min-w-0">
          <UnderstandColumn />
        </div>
        <div className="min-w-[85%] shrink-0 snap-center md:min-w-0">
          <CoordinateColumn />
        </div>
      </div>
    </div>
  );
}
