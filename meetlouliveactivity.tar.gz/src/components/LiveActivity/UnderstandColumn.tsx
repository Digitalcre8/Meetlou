import { useCase } from '../../state/CaseProvider';
import { StatusPill } from '../StatusPill';

function Row({ label, value, emphasis }: { label: string; value: string; emphasis?: boolean }) {
  return (
    <div className="flex items-center justify-between rounded-lg border border-hairline bg-white px-3 py-2.5">
      <span className="font-mono text-[11px] uppercase tracking-label text-stone">{label}</span>
      <span
        className={`rounded-full px-2.5 py-1 text-xs ${
          emphasis ? 'bg-terracotta font-semibold text-white' : 'bg-terracotta-tint text-ink'
        }`}
      >
        {value}
      </span>
    </div>
  );
}

export function UnderstandColumn() {
  const { timelineEvents, goToEvent } = useCase();
  const call = timelineEvents.find((e) => e.id === 'evt-call-solicitor')!;
  const minutes = Math.round((call.durationSeconds ?? 0) / 60);

  return (
    <div className="flex flex-col">
      <span className="font-mono text-[11px] uppercase tracking-label text-terracotta">Understand</span>

      <div className="mt-2 rounded-card border border-hairline bg-white p-4">
        <div className="flex items-center justify-between">
          <span className="font-mono text-[11px] uppercase tracking-label text-stone">AI Extracted</span>
          {call.verified && <StatusPill tone="verified" label="Verified" />}
        </div>

        <button onClick={() => goToEvent(call.id)} className="mt-3 block w-full text-left">
          <span className="font-heading text-base font-semibold text-ink">
            {call.title} · {minutes} min
          </span>
        </button>

        <div className="mt-3 rounded-lg bg-background p-3">
          <p className="text-sm leading-relaxed text-ink">{call.aiSummary}</p>
        </div>

        <div className="mt-3 space-y-2">
          <Row label="Decision" value={call.decision ?? ''} />
          <Row label="Action" value={call.action ?? ''} />
          <Row label="Deadline" value={call.deadline ?? ''} emphasis />
        </div>
      </div>

      <div className="mt-4">
        <p className="font-heading text-base font-semibold text-ink">
          AI extracts actions, summaries and deadlines.
        </p>
      </div>
    </div>
  );
}
