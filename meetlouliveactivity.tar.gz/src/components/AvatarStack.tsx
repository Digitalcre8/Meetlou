import type { Participant } from '../types';

interface AvatarStackProps {
  people: Participant[];
  max?: number;
}

export function AvatarStack({ people, max = 4 }: AvatarStackProps) {
  const shown = people.slice(0, max);
  const rest = people.length - shown.length;

  return (
    <div className="flex items-center">
      <div className="flex -space-x-2">
        {shown.map((p) => (
          <div
            key={p.id}
            title={p.name}
            className="flex h-8 w-8 items-center justify-center rounded-full border-2 border-white bg-ink font-mono text-[11px] text-white"
          >
            {p.initials}
          </div>
        ))}
      </div>
      {rest > 0 && <span className="ml-2 text-xs text-stone">+{rest} others</span>}
    </div>
  );
}
