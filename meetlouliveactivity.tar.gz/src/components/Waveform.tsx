import { useEffect, useRef, useState } from 'react';

const BAR_COUNT = 40;
const randomHeight = () => 15 + Math.random() * 85;

interface WaveformProps {
  active: boolean;
}

export function Waveform({ active }: WaveformProps) {
  const [bars, setBars] = useState<number[]>(() =>
    Array.from({ length: BAR_COUNT }, () => randomHeight()),
  );
  const intervalRef = useRef<number>();

  useEffect(() => {
    if (!active) return;
    intervalRef.current = window.setInterval(() => {
      setBars((prev) => [...prev.slice(1), randomHeight()]);
    }, 120);
    return () => window.clearInterval(intervalRef.current);
  }, [active]);

  return (
    <div className="flex h-12 items-end gap-[2px]" aria-hidden="true">
      {bars.map((h, i) => {
        const recency = i / (bars.length - 1);
        const opacity = active ? 0.3 + recency * 0.7 : 0.4;
        return (
          <div
            key={i}
            className="w-[3px] flex-1 rounded-t bg-terracotta transition-[height] duration-150 ease-out"
            style={{ height: `${h}%`, opacity }}
          />
        );
      })}
    </div>
  );
}
