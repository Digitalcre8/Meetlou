import type { TabId } from '../state/CaseProvider';

const TABS: { id: TabId; label: string }[] = [
  { id: 'live', label: 'Live' },
  { id: 'timeline', label: 'Timeline' },
  { id: 'documents', label: 'Documents' },
  { id: 'people', label: 'People' },
  { id: 'tasks', label: 'Tasks' },
];

interface TabsProps {
  active: TabId;
  onChange: (tab: TabId) => void;
}

export function Tabs({ active, onChange }: TabsProps) {
  return (
    <div className="flex gap-6 border-b border-hairline">
      {TABS.map((tab) => (
        <button
          key={tab.id}
          onClick={() => onChange(tab.id)}
          className={`-mb-px border-b-2 px-1 pb-3 font-heading text-sm transition-colors ${
            active === tab.id
              ? 'border-terracotta text-ink'
              : 'border-transparent text-stone hover:text-ink'
          }`}
        >
          {tab.label}
        </button>
      ))}
    </div>
  );
}
