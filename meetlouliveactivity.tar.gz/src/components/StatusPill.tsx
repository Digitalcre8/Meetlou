interface StatusPillProps {
  tone: 'recording' | 'verified' | 'neutral';
  label: string;
}

const toneStyles: Record<StatusPillProps['tone'], string> = {
  recording: 'bg-terracotta/10 text-terracotta',
  verified: 'bg-emerald-600/10 text-emerald-700',
  neutral: 'bg-hairline/60 text-stone',
};

const dotStyles: Record<StatusPillProps['tone'], string> = {
  recording: 'bg-terracotta animate-pulseDot',
  verified: 'bg-emerald-600',
  neutral: 'bg-stone',
};

export function StatusPill({ tone, label }: StatusPillProps) {
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 font-mono text-[11px] uppercase tracking-label ${toneStyles[tone]}`}
    >
      <span className={`h-1.5 w-1.5 rounded-full ${dotStyles[tone]}`} />
      {label}
    </span>
  );
}
