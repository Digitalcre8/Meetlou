import { useCase } from '../state/CaseProvider';

export function DocumentsTab() {
  const { timelineEvents } = useCase();
  const documents = timelineEvents.filter((e) => e.kind === 'document_upload');

  return (
    <div className="space-y-3">
      {documents.map((doc) => (
        <div key={doc.id} className="rounded-lg border border-hairline bg-white p-4">
          <div className="flex items-center justify-between">
            <p className="font-heading text-sm font-semibold text-ink">{doc.title}</p>
            <span className="font-mono text-[11px] uppercase tracking-label text-stone">
              {doc.status === 'complete' ? 'Done' : `${doc.progressPercent ?? 0}%`}
            </span>
          </div>
        </div>
      ))}
    </div>
  );
}
