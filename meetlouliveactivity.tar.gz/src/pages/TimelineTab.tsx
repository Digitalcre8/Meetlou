import { useEffect, useRef } from 'react';
import { useCase } from '../state/CaseProvider';
import { timeAgo } from '../components/LiveActivity/timeAgo';

const KIND_LABEL: Record<string, string> = {
  call: 'Call',
  email_sync: 'Email',
  document_upload: 'Document',
  note: 'Note',
  confirmation: 'Confirmation',
};

export function TimelineTab() {
  const { timelineEvents, highlightEventId } = useCase();
  const highlightRef = useRef<HTMLDivElement>(null);

  const sorted = [...timelineEvents].sort(
    (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime(),
  );

  useEffect(() => {
    if (highlightEventId && highlightRef.current) {
      highlightRef.current.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  }, [highlightEventId]);

  return (
    <div className="space-y-3">
      {sorted.map((event) => {
        const isHighlighted = event.id === highlightEventId;
        return (
          <div
            key={event.id}
            ref={isHighlighted ? highlightRef : undefined}
            className={`rounded-lg border bg-white p-4 transition-colors ${
              isHighlighted ? 'border-terracotta ring-2 ring-terracotta/30' : 'border-hairline'
            }`}
          >
            <div className="flex items-center justify-between">
              <span className="font-mono text-[11px] uppercase tracking-label text-stone">
                {KIND_LABEL[event.kind]}
              </span>
              <span className="text-xs text-stone">{timeAgo(event.createdAt)}</span>
            </div>
            <p className="mt-1 font-heading text-sm font-semibold text-ink">{event.title}</p>
            {event.aiSummary && <p className="mt-1 text-sm text-stone">{event.aiSummary}</p>}
          </div>
        );
      })}
    </div>
  );
}
