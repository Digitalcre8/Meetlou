import { useCase } from '../state/CaseProvider';
import { Tabs } from '../components/Tabs';
import { LiveActivity } from '../components/LiveActivity/LiveActivity';
import { TimelineTab } from './TimelineTab';
import { DocumentsTab } from './DocumentsTab';
import { PeopleTab } from './PeopleTab';
import { TasksTab } from './TasksTab';

export function CaseDetail() {
  const { caseRecord, activeTab, setActiveTab } = useCase();

  return (
    <div className="mx-auto max-w-5xl px-4 py-8 sm:px-6">
      <p className="font-mono text-[11px] uppercase tracking-label text-stone">Case</p>
      <h1 className="mt-1 font-heading text-2xl font-semibold text-ink">{caseRecord.title}</h1>
      <p className="mt-1 text-sm text-stone">{caseRecord.address}</p>

      <div className="mt-6">
        <Tabs active={activeTab} onChange={setActiveTab} />
      </div>

      <div className="mt-6">
        {activeTab === 'live' && <LiveActivity />}
        {activeTab === 'timeline' && <TimelineTab />}
        {activeTab === 'documents' && <DocumentsTab />}
        {activeTab === 'people' && <PeopleTab />}
        {activeTab === 'tasks' && <TasksTab />}
      </div>
    </div>
  );
}
