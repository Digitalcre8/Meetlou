import { useCase } from '../state/CaseProvider';

export function TasksTab() {
  const { tasks } = useCase();

  return (
    <div className="space-y-3">
      {tasks.map((task) => (
        <div key={task.id} className="flex items-center justify-between rounded-lg border border-hairline bg-white p-4">
          <div className="flex items-center gap-3">
            <span
              className={`flex h-5 w-5 items-center justify-center rounded-full border text-[10px] ${
                task.done ? 'border-terracotta bg-terracotta text-white' : 'border-hairline text-transparent'
              }`}
            >
              ✓
            </span>
            <p className={`text-sm ${task.done ? 'text-stone line-through' : 'text-ink'}`}>{task.title}</p>
          </div>
          {task.dueDate && <span className="text-xs text-stone">{task.dueDate}</span>}
        </div>
      ))}
    </div>
  );
}
