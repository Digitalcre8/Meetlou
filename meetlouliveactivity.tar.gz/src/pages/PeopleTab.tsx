import { useCase } from '../state/CaseProvider';

const ROLE_LABEL: Record<string, string> = {
  you: 'You',
  buyer: 'Buyer',
  seller: 'Seller',
  estate_agent: 'Estate Agent',
  solicitor: 'Solicitor',
  mortgage_broker: 'Mortgage Broker',
  surveyor: 'Surveyor',
};

export function PeopleTab() {
  const { participants, caseRecord } = useCase();
  const people = participants.filter((p) => caseRecord.participantIds.includes(p.id));

  return (
    <div className="space-y-3">
      {people.map((p) => (
        <div key={p.id} className="flex items-center gap-3 rounded-lg border border-hairline bg-white p-4">
          <div className="flex h-9 w-9 items-center justify-center rounded-full bg-ink font-mono text-[11px] text-white">
            {p.initials}
          </div>
          <div>
            <p className="font-heading text-sm font-semibold text-ink">{p.name}</p>
            <p className="text-xs text-stone">{ROLE_LABEL[p.role]}</p>
          </div>
        </div>
      ))}
    </div>
  );
}
