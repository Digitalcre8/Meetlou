import type { Case, Participant, ReadReceipt, Task, TimelineEvent } from '../types';

export const CASE_ID = 'case-1';

export const caseRecord: Case = {
  id: CASE_ID,
  title: '34 Ashgrove Road',
  address: '34 Ashgrove Road, Bristol BS6 7UN',
  participantIds: ['you', 'p-agent', 'p-solicitor', 'p-broker', 'p-buyer', 'p-surveyor'],
};

export const participants: Participant[] = [
  { id: 'you', name: 'You', initials: 'Y', role: 'you' },
  { id: 'p-agent', name: 'Estate Agent', initials: 'EA', role: 'estate_agent' },
  { id: 'p-solicitor', name: 'Solicitor', initials: 'S', role: 'solicitor' },
  { id: 'p-broker', name: 'Mortgage Broker', initials: 'MB', role: 'mortgage_broker' },
  { id: 'p-buyer', name: 'Buyer', initials: 'B', role: 'buyer' },
  { id: 'p-surveyor', name: 'Surveyor', initials: 'SV', role: 'surveyor' },
];

const now = Date.now();
const minutesAgo = (m: number) => new Date(now - m * 60_000).toISOString();

export const initialTimelineEvents: TimelineEvent[] = [
  {
    id: 'evt-live-call',
    caseId: CASE_ID,
    kind: 'call',
    title: 'Call with estate agent',
    createdAt: minutesAgo(0),
    status: 'live',
    durationSeconds: 372,
  },
  {
    id: 'evt-email-sync',
    caseId: CASE_ID,
    kind: 'email_sync',
    title: 'Synced 24 emails',
    createdAt: minutesAgo(4),
    status: 'complete',
    emailCount: 24,
  },
  {
    id: 'evt-upload-survey',
    caseId: CASE_ID,
    kind: 'document_upload',
    title: 'Uploading survey.pdf',
    createdAt: minutesAgo(1),
    status: 'processing',
    progressPercent: 82,
  },
  {
    id: 'evt-call-solicitor',
    caseId: CASE_ID,
    kind: 'call',
    title: 'Call with solicitor',
    createdAt: minutesAgo(45),
    status: 'complete',
    durationSeconds: 360,
    verified: true,
    aiSummary:
      'Solicitor confirmed searches are back with no issues. They recommend proceeding with the offer and want proof of funds sent before Friday to keep exchange on track.',
    decision: 'Proceed with offer at £425,000',
    action: 'Send proof of funds to solicitor',
    deadline: 'Fri, 18 Jul',
  },
  {
    id: 'evt-share-mortgage-offer',
    caseId: CASE_ID,
    kind: 'document_upload',
    title: "You shared 'Mortgage offer.pdf'",
    createdAt: minutesAgo(38),
    status: 'complete',
    actorParticipantId: 'you',
    actorLabel: 'You',
  },
  {
    id: 'evt-note-solicitor',
    caseId: CASE_ID,
    kind: 'note',
    title: 'Solicitor added a note',
    createdAt: minutesAgo(2),
    status: 'complete',
    actorParticipantId: 'p-solicitor',
    actorLabel: 'Solicitor',
  },
  {
    id: 'evt-confirm-viewing',
    caseId: CASE_ID,
    kind: 'confirmation',
    title: 'Agent confirmed Thursday viewing',
    createdAt: minutesAgo(20),
    status: 'complete',
    actorParticipantId: 'p-agent',
    actorLabel: 'Agent',
  },
];

const allRead = (eventId: string): ReadReceipt[] =>
  participants
    .filter((p) => p.id !== 'you')
    .map((p) => ({ timelineEventId: eventId, participantId: p.id, readAt: minutesAgo(1) }));

export const initialReadReceipts: ReadReceipt[] = [
  ...allRead('evt-share-mortgage-offer'),
  { timelineEventId: 'evt-confirm-viewing', participantId: 'p-agent', readAt: minutesAgo(19) },
  { timelineEventId: 'evt-confirm-viewing', participantId: 'p-solicitor', readAt: minutesAgo(15) },
  { timelineEventId: 'evt-confirm-viewing', participantId: 'p-buyer', readAt: minutesAgo(10) },
  { timelineEventId: 'evt-confirm-viewing', participantId: 'p-broker', readAt: null },
  { timelineEventId: 'evt-confirm-viewing', participantId: 'p-surveyor', readAt: null },
];

export const initialTasks: Task[] = [
  { id: 'task-1', caseId: CASE_ID, title: 'Send proof of funds to solicitor', dueDate: 'Fri, 18 Jul', done: false },
  { id: 'task-2', caseId: CASE_ID, title: 'Confirm Thursday viewing time', dueDate: 'Thu, 17 Jul', done: true },
  { id: 'task-3', caseId: CASE_ID, title: 'Review survey report', dueDate: 'Mon, 21 Jul', done: false },
];
